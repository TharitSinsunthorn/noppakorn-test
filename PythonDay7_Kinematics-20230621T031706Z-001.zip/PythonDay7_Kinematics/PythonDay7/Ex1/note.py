import numpy as np
import math

print(np.arcsin(np.arctan2(1,3)))